# Replit Configuration - Meter-On Cab Booking Application

## Overview

This is a full-stack cab booking application called "Meter-On" built with a modern TypeScript stack. The application provides a complete ride-booking platform similar to Uber/Ola with user authentication, cab management, booking functionality, and admin dashboard capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight client-side routing)
- **UI Framework**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query (React Query) for server state
- **Forms**: React Hook Form with Zod validation
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Authentication**: Replit Auth (OpenID Connect) with session management
- **Session Storage**: PostgreSQL-based sessions using connect-pg-simple
- **API Design**: RESTful endpoints with centralized error handling

### Database Architecture
- **Database**: PostgreSQL (configured for Neon serverless)
- **ORM**: Drizzle ORM with type-safe schema definitions
- **Migration Tool**: Drizzle Kit for schema management
- **Connection**: Serverless connection pooling via @neondatabase/serverless

## Key Components

### Authentication System
- **Provider**: Replit Auth integration with OpenID Connect
- **Session Management**: Server-side sessions stored in PostgreSQL
- **Middleware**: Authentication guards for protected routes
- **User Management**: Automatic user creation/updates on login

### Cab Booking System
- **Cab Types**: Multi-tier vehicle options (Mini, Sedan, SUV) with pricing
- **Booking Flow**: Location selection, vehicle choice, fare calculation, confirmation
- **Status Management**: Booking lifecycle tracking (pending, confirmed, completed, cancelled)
- **History**: User booking history with filtering capabilities

### Admin Dashboard
- **Analytics**: Dashboard with key metrics (users, bookings, revenue)
- **Booking Management**: View, filter, and manage all bookings
- **User Management**: Customer data and booking history oversight
- **Cab Type Configuration**: Dynamic pricing and vehicle type management

### Email Service
- **Notifications**: Booking confirmations and admin alerts
- **Implementation**: Mock service with console logging (ready for SMTP integration)
- **Templates**: Structured email content for different notification types

## Data Flow

### User Authentication Flow
1. User clicks login → Replit Auth redirect
2. OAuth callback processes user data
3. User session created/updated in database
4. Frontend receives authenticated user state

### Booking Creation Flow
1. User selects pickup/drop locations
2. System calculates fare based on cab type pricing
3. Booking created with pending status
4. Email confirmation sent to user
5. Admin notification triggered

### Admin Management Flow
1. Admin accesses dashboard with real-time stats
2. Booking management interface shows all bookings
3. Status updates propagate through system
4. Analytics refresh automatically

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL serverless connection
- **drizzle-orm**: Type-safe database operations
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI primitives
- **react-hook-form**: Form handling and validation
- **zod**: Runtime type validation

### Development Tools
- **tsx**: TypeScript execution for development
- **esbuild**: Production bundle building
- **vite**: Frontend development server and bundling
- **tailwindcss**: Utility-first CSS framework

### Authentication & Session
- **passport**: Authentication middleware
- **openid-client**: OpenID Connect implementation
- **connect-pg-simple**: PostgreSQL session store
- **express-session**: Session management

## Deployment Strategy

### Development Environment
- **Server**: Express with Vite middleware for HMR
- **Database**: Neon PostgreSQL with connection pooling
- **Build Process**: TypeScript compilation with hot reloading
- **Asset Serving**: Vite handles static assets and React app

### Production Deployment
- **Build**: Frontend built to static assets, backend bundled with esbuild
- **Database**: Persistent PostgreSQL with environment-based configuration
- **Environment Variables**: DATABASE_URL, SESSION_SECRET, REPLIT_* for auth
- **Static Serving**: Express serves built React app from dist/public

### Database Management
- **Schema**: Defined in shared/schema.ts with Drizzle
- **Migrations**: Generated and applied via drizzle-kit
- **Environment**: Configurable connection via DATABASE_URL
- **Tables**: Users, bookings, cab types, and sessions (required for auth)

The application is designed for Replit deployment with integrated authentication, but can be adapted for other platforms by replacing the auth system and adjusting environment configuration.

## Recent Changes: Latest modifications with dates

### January 17, 2025
- **Interactive Map System**: Added comprehensive map component with visual route display
- **Real-time Features**: Implemented live booking clock with current time/date
- **Enhanced UX**: Added animated markers, route visualization, and distance/time display
- **Visual Improvements**: Map shows pickup/drop locations, moving car icon, and interactive controls
- **Database Fixes**: Resolved TypeScript errors in storage operations for booking system