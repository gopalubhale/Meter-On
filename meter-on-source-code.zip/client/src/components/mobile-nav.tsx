import { Link, useLocation } from "wouter";
import { Home, Car, BarChart3, User } from "lucide-react";

export default function MobileNav() {
  const [location] = useLocation();

  const isActive = (path: string) => location === path;

  return (
    <div className="md:hidden bg-white border-t border-gray-200 fixed bottom-0 left-0 right-0 z-50">
      <div className="flex justify-around py-2">
        <Link href="/">
          <button className="flex flex-col items-center p-2">
            <Home className={`h-5 w-5 ${isActive('/') ? 'text-primary' : 'text-gray-400'}`} />
            <span className={`text-xs mt-1 ${isActive('/') ? 'text-primary' : 'text-gray-600'}`}>
              Home
            </span>
          </button>
        </Link>
        <Link href="/booking">
          <button className="flex flex-col items-center p-2">
            <Car className={`h-5 w-5 ${isActive('/booking') ? 'text-primary' : 'text-gray-400'}`} />
            <span className={`text-xs mt-1 ${isActive('/booking') ? 'text-primary' : 'text-gray-600'}`}>
              Book
            </span>
          </button>
        </Link>
        <Link href="/admin">
          <button className="flex flex-col items-center p-2">
            <BarChart3 className={`h-5 w-5 ${isActive('/admin') ? 'text-primary' : 'text-gray-400'}`} />
            <span className={`text-xs mt-1 ${isActive('/admin') ? 'text-primary' : 'text-gray-600'}`}>
              Admin
            </span>
          </button>
        </Link>
        <Link href="/profile">
          <button className="flex flex-col items-center p-2">
            <User className={`h-5 w-5 ${isActive('/profile') ? 'text-primary' : 'text-gray-400'}`} />
            <span className={`text-xs mt-1 ${isActive('/profile') ? 'text-primary' : 'text-gray-600'}`}>
              Profile
            </span>
          </button>
        </Link>
      </div>
    </div>
  );
}
