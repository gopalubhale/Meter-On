import { useState, useEffect } from 'react';
import { MapPin, Navigation, Zap } from 'lucide-react';

interface MapProps {
  pickupLocation?: string;
  dropLocation?: string;
  distance?: number;
  estimatedTime?: number;
}

export default function InteractiveMap({ pickupLocation, dropLocation, distance, estimatedTime }: MapProps) {
  const [mapLoaded, setMapLoaded] = useState(false);
  const [routePoints, setRoutePoints] = useState<{ lat: number; lng: number }[]>([]);

  useEffect(() => {
    // Simulate map loading
    const timer = setTimeout(() => {
      setMapLoaded(true);
      
      // Generate mock route points if both locations are provided
      if (pickupLocation && dropLocation) {
        const mockRoute = [
          { lat: 28.6139, lng: 77.2090 }, // Start point (Delhi)
          { lat: 28.6200, lng: 77.2150 }, // Waypoint 1
          { lat: 28.6250, lng: 77.2200 }, // Waypoint 2
          { lat: 28.6300, lng: 77.2250 }, // End point
        ];
        setRoutePoints(mockRoute);
      }
    }, 1000);

    return () => clearTimeout(timer);
  }, [pickupLocation, dropLocation]);

  const hasRoute = pickupLocation && dropLocation;

  return (
    <div className="relative w-full h-64 bg-gradient-to-br from-blue-50 to-green-50 rounded-lg overflow-hidden border-2 border-gray-200 shadow-lg">
      {/* Map Container */}
      <div className="relative w-full h-full">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-20">
          <div className="w-full h-full" style={{
            backgroundImage: `
              linear-gradient(90deg, rgba(0,0,0,0.1) 1px, transparent 1px),
              linear-gradient(rgba(0,0,0,0.1) 1px, transparent 1px)
            `,
            backgroundSize: '20px 20px'
          }}></div>
        </div>

        {/* Map Content */}
        {!mapLoaded ? (
          <div className="absolute inset-0 flex items-center justify-center bg-white bg-opacity-80">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-gray-600 font-medium">Loading Interactive Map...</p>
            </div>
          </div>
        ) : (
          <div className="absolute inset-0">
            {/* Map Background */}
            <div className="w-full h-full relative">
              
              {/* Streets/Roads */}
              <div className="absolute inset-0">
                <svg width="100%" height="100%" className="absolute inset-0" viewBox="0 0 400 300">
                  <defs>
                    <linearGradient id="roadGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#d1d5db" />
                      <stop offset="100%" stopColor="#9ca3af" />
                    </linearGradient>
                  </defs>
                  {/* Main roads */}
                  <line x1="0" y1="90" x2="400" y2="75" stroke="url(#roadGradient)" strokeWidth="4" />
                  <line x1="0" y1="180" x2="400" y2="195" stroke="url(#roadGradient)" strokeWidth="4" />
                  <line x1="80" y1="0" x2="100" y2="300" stroke="url(#roadGradient)" strokeWidth="4" />
                  <line x1="280" y1="0" x2="300" y2="300" stroke="url(#roadGradient)" strokeWidth="4" />
                  
                  {/* Building blocks */}
                  <rect x="20" y="20" width="50" height="40" fill="#f3f4f6" stroke="#e5e7eb" strokeWidth="1" />
                  <rect x="300" y="50" width="60" height="30" fill="#f3f4f6" stroke="#e5e7eb" strokeWidth="1" />
                  <rect x="150" y="200" width="80" height="50" fill="#f3f4f6" stroke="#e5e7eb" strokeWidth="1" />
                  <rect x="50" y="220" width="40" height="60" fill="#f3f4f6" stroke="#e5e7eb" strokeWidth="1" />
                </svg>
              </div>

              {/* Pickup Location */}
              {pickupLocation && (
                <div className="absolute" style={{ top: '20%', left: '15%' }}>
                  <div className="relative">
                    <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center shadow-lg animate-pulse">
                      <MapPin className="h-4 w-4 text-white" />
                    </div>
                    <div className="absolute top-8 left-1/2 transform -translate-x-1/2 bg-green-100 px-2 py-1 rounded text-xs font-medium text-green-800 whitespace-nowrap shadow-md">
                      Pickup: {pickupLocation.slice(0, 20)}...
                    </div>
                  </div>
                </div>
              )}

              {/* Drop Location */}
              {dropLocation && (
                <div className="absolute" style={{ bottom: '20%', right: '15%' }}>
                  <div className="relative">
                    <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center shadow-lg animate-pulse">
                      <MapPin className="h-4 w-4 text-white" />
                    </div>
                    <div className="absolute bottom-8 right-1/2 transform translate-x-1/2 bg-red-100 px-2 py-1 rounded text-xs font-medium text-red-800 whitespace-nowrap shadow-md">
                      Drop: {dropLocation.slice(0, 20)}...
                    </div>
                  </div>
                </div>
              )}

              {/* Route Line */}
              {hasRoute && (
                <div className="absolute inset-0">
                  <svg width="100%" height="100%" className="absolute inset-0" viewBox="0 0 400 300">
                    <defs>
                      <linearGradient id="routeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#f97316" />
                        <stop offset="50%" stopColor="#ea580c" />
                        <stop offset="100%" stopColor="#dc2626" />
                      </linearGradient>
                    </defs>
                    <path
                      d="M 60 60 Q 120 80 180 120 Q 240 160 320 240"
                      stroke="url(#routeGradient)"
                      strokeWidth="5"
                      fill="none"
                      strokeDasharray="10 5"
                      className="animate-pulse"
                    />
                    {/* Route direction arrows */}
                    <polygon points="140,100 150,95 150,105" fill="#f97316" />
                    <polygon points="200,140 210,135 210,145" fill="#ea580c" />
                    <polygon points="260,180 270,175 270,185" fill="#dc2626" />
                  </svg>
                </div>
              )}

              {/* Moving Car Icon */}
              {hasRoute && (
                <div className="absolute" style={{ top: '40%', left: '45%' }}>
                  <div className="bg-primary rounded-full p-2 shadow-lg animate-bounce">
                    <Navigation className="h-4 w-4 text-white transform rotate-45" />
                  </div>
                </div>
              )}

              {/* Distance & Time Info */}
              {distance && (
                <div className="absolute top-4 right-4 bg-white px-3 py-2 rounded-lg shadow-md">
                  <div className="flex items-center space-x-2 mb-1">
                    <Zap className="h-4 w-4 text-primary" />
                    <span className="text-sm font-medium text-gray-700">{distance} km</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Navigation className="h-4 w-4 text-green-600" />
                    <span className="text-sm font-medium text-gray-700">{estimatedTime || Math.round(distance * 2.5)} mins</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Map Controls */}
        <div className="absolute bottom-4 left-4 flex flex-col space-y-2">
          <button className="bg-white p-2 rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <span className="text-lg font-bold text-gray-600">+</span>
          </button>
          <button className="bg-white p-2 rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <span className="text-lg font-bold text-gray-600">-</span>
          </button>
        </div>
      </div>

      {/* Map Footer */}
      <div className="absolute bottom-0 left-0 right-0 bg-white bg-opacity-90 p-2">
        <div className="flex justify-between items-center text-xs text-gray-600">
          <span>Interactive Route Map</span>
          {hasRoute && (
            <span className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-primary rounded-full"></div>
              <span>Live Route</span>
            </span>
          )}
        </div>
      </div>
    </div>
  );
}