import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { CarTaxiFront } from "lucide-react";
import { Link, useLocation } from "wouter";

export default function Navigation() {
  const { user } = useAuth();
  const [location] = useLocation();

  const isActive = (path: string) => location === path;

  return (
    <nav className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <CarTaxiFront className="text-white h-6 w-6" />
              </div>
              <span className="ml-3 text-xl font-bold text-gray-900">Meter-On</span>
            </Link>
          </div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              <Link href="/">
                <Button 
                  variant="ghost" 
                  className={`${isActive('/') ? 'text-primary' : 'text-gray-500 hover:text-gray-900'}`}
                >
                  Home
                </Button>
              </Link>
              <Link href="/booking">
                <Button 
                  variant="ghost" 
                  className={`${isActive('/booking') ? 'text-primary' : 'text-gray-500 hover:text-gray-900'}`}
                >
                  Book Ride
                </Button>
              </Link>
              <Link href="/admin">
                <Button 
                  variant="ghost" 
                  className={`${isActive('/admin') ? 'text-primary' : 'text-gray-500 hover:text-gray-900'}`}
                >
                  Admin
                </Button>
              </Link>
              <Link href="/profile">
                <Button 
                  variant="ghost" 
                  className={`${isActive('/profile') ? 'text-primary' : 'text-gray-500 hover:text-gray-900'}`}
                >
                  Profile
                </Button>
              </Link>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            {user && (
              <span className="text-sm text-gray-600 hidden md:block">
                Welcome, {user.firstName}!
              </span>
            )}
            <Button 
              onClick={() => window.location.href = "/api/logout"}
              variant="outline"
            >
              Sign Out
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}
