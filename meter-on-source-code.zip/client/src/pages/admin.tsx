import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useToast } from "@/hooks/use-toast";
import Navigation from "@/components/navigation";
import MobileNav from "@/components/mobile-nav";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, Car, DollarSign, TrendingUp, Download, Bell, BarChart3 } from "lucide-react";

export default function Admin() {
  const { isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    retry: false,
  });

  const { data: allBookings, isLoading: bookingsLoading } = useQuery({
    queryKey: ["/api/bookings"],
    retry: false,
  });

  const handleAdminAction = (action: string) => {
    toast({
      title: "Action Triggered",
      description: `${action} functionality would be implemented here`,
    });
  };

  if (isLoading || statsLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-0">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-600 mt-2">Manage bookings, users, and monitor performance</p>
        </div>
        
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 bg-blue-100 rounded-full">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Users</p>
                  <p className="text-2xl font-semibold text-gray-900">
                    {stats?.totalUsers || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 bg-green-100 rounded-full">
                  <Car className="h-6 w-6 text-green-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Active Bookings</p>
                  <p className="text-2xl font-semibold text-gray-900">
                    {stats?.activeBookings || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 bg-yellow-100 rounded-full">
                  <DollarSign className="h-6 w-6 text-yellow-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Today's Revenue</p>
                  <p className="text-2xl font-semibold text-gray-900">
                    ₹{stats?.todayRevenue || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 bg-purple-100 rounded-full">
                  <TrendingUp className="h-6 w-6 text-purple-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Rides</p>
                  <p className="text-2xl font-semibold text-gray-900">
                    {stats?.totalRides || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Booking Management */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Recent Bookings */}
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Recent Bookings</h2>
                <Button variant="ghost" className="text-primary hover:text-primary/90 text-sm">
                  View All
                </Button>
              </div>
              
              {bookingsLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg animate-pulse">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gray-300 rounded-full"></div>
                        <div>
                          <div className="h-4 bg-gray-300 rounded w-24 mb-2"></div>
                          <div className="h-3 bg-gray-300 rounded w-32"></div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="h-4 bg-gray-300 rounded w-16 mb-2"></div>
                        <div className="h-3 bg-gray-300 rounded w-20"></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : allBookings && allBookings.length > 0 ? (
                <div className="space-y-4">
                  {allBookings.slice(0, 5).map((booking: any) => (
                    <div key={booking.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                          <span className="text-sm font-medium text-gray-600">
                            {booking.user?.firstName?.charAt(0) || 'U'}
                            {booking.user?.lastName?.charAt(0) || ''}
                          </span>
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">
                            {booking.user?.firstName} {booking.user?.lastName}
                          </p>
                          <p className="text-sm text-gray-500">
                            {booking.pickupLocation} → {booking.dropLocation}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-primary">₹{booking.fare}</p>
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          booking.status === 'completed' ? 'bg-green-100 text-green-800' :
                          booking.status === 'ongoing' ? 'bg-yellow-100 text-yellow-800' :
                          booking.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                          'bg-blue-100 text-blue-800'
                        }`}>
                          {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Car className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">No bookings yet</p>
                  <p className="text-sm text-gray-400">Bookings will appear here when users start booking rides</p>
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* User Management */}
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-900">User Management</h2>
                <Button variant="ghost" className="text-primary hover:text-primary/90 text-sm">
                  View All
                </Button>
              </div>
              
              <div className="text-center py-8">
                <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">User management</p>
                <p className="text-sm text-gray-400">Detailed user management features would be implemented here</p>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Actions Panel */}
        <div className="mt-8 grid md:grid-cols-3 gap-6">
          <Button 
            onClick={() => handleAdminAction("Export Bookings")}
            className="bg-primary hover:bg-primary/90 p-4 h-auto flex items-center justify-center gap-2"
          >
            <Download className="h-5 w-5" />
            Export Bookings
          </Button>
          <Button 
            onClick={() => handleAdminAction("Send Notifications")}
            className="bg-green-600 hover:bg-green-700 p-4 h-auto flex items-center justify-center gap-2"
          >
            <Bell className="h-5 w-5" />
            Send Notifications
          </Button>
          <Button 
            onClick={() => handleAdminAction("Generate Report")}
            className="bg-blue-600 hover:bg-blue-700 p-4 h-auto flex items-center justify-center gap-2"
          >
            <BarChart3 className="h-5 w-5" />
            Generate Report
          </Button>
        </div>
      </div>

      <MobileNav />
    </div>
  );
}
