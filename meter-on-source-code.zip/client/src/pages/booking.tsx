import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Navigation from "@/components/navigation";
import MobileNav from "@/components/mobile-nav";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { MapPin, Car, Clock, Calendar } from "lucide-react";
import type { CabType, Booking } from "@shared/schema";
import InteractiveMap from "@/components/map";
import BookingTime from "@/components/booking-time";

const bookingSchema = z.object({
  pickupLocation: z.string().min(1, "Pickup location is required"),
  dropLocation: z.string().min(1, "Drop location is required"),
  cabTypeId: z.string().min(1, "Please select a vehicle type"),
  scheduledAt: z.string().optional(),
  notes: z.string().optional(),
});

type BookingFormData = z.infer<typeof bookingSchema>;

export default function Booking() {
  const { isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [fareEstimate, setFareEstimate] = useState<any>(null);
  const [estimatedDistance] = useState(12.5); // Mock distance for demo

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const form = useForm<BookingFormData>({
    resolver: zodResolver(bookingSchema),
    defaultValues: {
      pickupLocation: "",
      dropLocation: "",
      cabTypeId: "",
      scheduledAt: "",
      notes: "",
    },
  });

  const { data: cabTypes, isLoading: cabTypesLoading } = useQuery<CabType[]>({
    queryKey: ["/api/cab-types"],
  });

  const { data: userBookings, isLoading: bookingsLoading } = useQuery<Booking[]>({
    queryKey: ["/api/bookings/user"],
    retry: false,
  });

  const bookingMutation = useMutation({
    mutationFn: async (data: BookingFormData) => {
      const fareData = await calculateFare(parseInt(data.cabTypeId));
      const bookingData = {
        ...data,
        cabTypeId: parseInt(data.cabTypeId),
        fare: fareData.totalFare.toString(),
        estimatedDistance: estimatedDistance.toString(),
        scheduledAt: data.scheduledAt ? new Date(data.scheduledAt).toISOString() : null,
      };
      
      await apiRequest("POST", "/api/bookings", bookingData);
    },
    onSuccess: () => {
      toast({
        title: "Booking Confirmed!",
        description: "Your ride has been booked successfully. You will receive a confirmation email shortly.",
      });
      form.reset();
      setFareEstimate(null);
      queryClient.invalidateQueries({ queryKey: ["/api/bookings/user"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Booking Failed",
        description: "Failed to book your ride. Please try again.",
        variant: "destructive",
      });
    },
  });

  const calculateFare = async (cabTypeId: number) => {
    const response = await fetch("/api/calculate-fare", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ distance: estimatedDistance, cabTypeId }),
    });
    return response.json();
  };

  const selectedCabTypeId = form.watch("cabTypeId");

  useEffect(() => {
    if (selectedCabTypeId && cabTypes) {
      calculateFare(parseInt(selectedCabTypeId)).then(setFareEstimate);
    }
  }, [selectedCabTypeId, cabTypes]);

  const onSubmit = (data: BookingFormData) => {
    bookingMutation.mutate(data);
  };

  if (isLoading) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-0">
      <Navigation />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Booking Time Display */}
        <div className="mb-6">
          <BookingTime />
        </div>
        
        <Card>
          <CardContent className="p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Book Your Ride</h2>
            
            <form onSubmit={form.handleSubmit(onSubmit)} className="grid md:grid-cols-2 gap-8">
              <div className="space-y-6">
                {/* Pickup Location */}
                <div>
                  <Label htmlFor="pickupLocation">Pickup Location</Label>
                  <div className="relative mt-2">
                    <MapPin className="absolute left-3 top-3 h-4 w-4 text-green-500" />
                    <Input
                      id="pickupLocation"
                      placeholder="Enter pickup location"
                      className="pl-10"
                      {...form.register("pickupLocation")}
                    />
                  </div>
                  {form.formState.errors.pickupLocation && (
                    <p className="text-sm text-destructive mt-1">
                      {form.formState.errors.pickupLocation.message}
                    </p>
                  )}
                </div>
                
                {/* Drop Location */}
                <div>
                  <Label htmlFor="dropLocation">Drop Location</Label>
                  <div className="relative mt-2">
                    <MapPin className="absolute left-3 top-3 h-4 w-4 text-red-500" />
                    <Input
                      id="dropLocation"
                      placeholder="Enter destination"
                      className="pl-10"
                      {...form.register("dropLocation")}
                    />
                  </div>
                  {form.formState.errors.dropLocation && (
                    <p className="text-sm text-destructive mt-1">
                      {form.formState.errors.dropLocation.message}
                    </p>
                  )}
                </div>
                
                {/* Scheduled Time */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="scheduledAt">Schedule Time (Optional)</Label>
                    <div className="relative mt-2">
                      <Calendar className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
                      <Input
                        id="scheduledAt"
                        type="datetime-local"
                        className="pl-10"
                        {...form.register("scheduledAt")}
                      />
                    </div>
                  </div>
                </div>
                
                {/* Vehicle Selection */}
                <div>
                  <Label>Select Vehicle Type</Label>
                  <RadioGroup
                    value={form.watch("cabTypeId")}
                    onValueChange={(value) => form.setValue("cabTypeId", value)}
                    className="mt-3 space-y-3"
                  >
                    {cabTypesLoading ? (
                      <div className="space-y-3">
                        {[1, 2, 3].map((i) => (
                          <div key={i} className="flex items-center space-x-3 p-3 border border-gray-300 rounded-lg animate-pulse">
                            <div className="w-4 h-4 bg-gray-300 rounded-full"></div>
                            <div className="flex-1">
                              <div className="h-4 bg-gray-300 rounded w-1/3 mb-2"></div>
                              <div className="h-3 bg-gray-300 rounded w-1/2"></div>
                            </div>
                            <div className="h-4 bg-gray-300 rounded w-16"></div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      cabTypes?.map((cabType) => (
                        <div key={cabType.id} className="flex items-center space-x-3 p-3 border border-gray-300 rounded-lg hover:border-primary cursor-pointer">
                          <RadioGroupItem value={cabType.id.toString()} id={`cabType-${cabType.id}`} />
                          <Label htmlFor={`cabType-${cabType.id}`} className="flex-1 cursor-pointer">
                            <div className="flex justify-between items-center">
                              <span className="font-medium text-gray-900">{cabType.type}</span>
                              <span className="text-primary font-semibold">₹{cabType.perKmRate}/km</span>
                            </div>
                            <span className="text-sm text-gray-500">{cabType.description}</span>
                          </Label>
                        </div>
                      ))
                    )}
                  </RadioGroup>
                  {form.formState.errors.cabTypeId && (
                    <p className="text-sm text-destructive mt-1">
                      {form.formState.errors.cabTypeId.message}
                    </p>
                  )}
                </div>
              </div>
              
              {/* Map & Fare Estimate */}
              <div className="space-y-6">
                {/* Interactive Map */}
                <InteractiveMap
                  pickupLocation={form.watch("pickupLocation")}
                  dropLocation={form.watch("dropLocation")}
                  distance={estimatedDistance}
                />
                
                {/* Fare Estimate */}
                {fareEstimate && (
                  <Card className="bg-gray-50">
                    <CardContent className="p-4">
                      <h3 className="font-semibold text-gray-900 mb-3">Fare Estimate</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Distance</span>
                          <span className="font-medium">{fareEstimate.distance} km</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Base Fare</span>
                          <span className="font-medium">₹{fareEstimate.baseFare}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Per Km (₹{fareEstimate.perKmRate}/km)</span>
                          <span className="font-medium">₹{(fareEstimate.distance * fareEstimate.perKmRate).toFixed(2)}</span>
                        </div>
                        <Separator />
                        <div className="flex justify-between text-lg font-semibold">
                          <span>Total Fare</span>
                          <span className="text-primary">₹{fareEstimate.totalFare}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
                
                {/* Book Button */}
                <Button 
                  type="submit" 
                  className="w-full bg-primary hover:bg-primary/90" 
                  size="lg"
                  disabled={bookingMutation.isPending}
                >
                  {bookingMutation.isPending ? "Booking..." : "Confirm Booking"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
        
        {/* Recent Bookings */}
        <Card className="mt-6">
          <CardContent className="p-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Recent Bookings</h3>
            {bookingsLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg animate-pulse">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gray-300 rounded-full"></div>
                      <div>
                        <div className="h-4 bg-gray-300 rounded w-32 mb-2"></div>
                        <div className="h-3 bg-gray-300 rounded w-24"></div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="h-4 bg-gray-300 rounded w-16 mb-2"></div>
                      <div className="h-3 bg-gray-300 rounded w-20"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : userBookings && userBookings.length > 0 ? (
              <div className="space-y-4">
                {userBookings.slice(0, 5).map((booking) => (
                  <div key={booking.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                        <Car className="text-white h-6 w-6" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{booking.pickupLocation} → {booking.dropLocation}</p>
                        <p className="text-sm text-gray-500">
                          {booking.bookedAt && new Date(booking.bookedAt).toLocaleDateString()} - {booking.bookedAt && new Date(booking.bookedAt).toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-primary">₹{booking.fare}</p>
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        booking.status === 'completed' ? 'bg-green-100 text-green-800' :
                        booking.status === 'ongoing' ? 'bg-yellow-100 text-yellow-800' :
                        booking.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                        'bg-blue-100 text-blue-800'
                      }`}>
                        {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Car className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">No bookings yet</p>
                <p className="text-sm text-gray-400">Your ride history will appear here</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <MobileNav />
    </div>
  );
}
