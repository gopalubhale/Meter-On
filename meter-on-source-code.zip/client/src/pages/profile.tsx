import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useToast } from "@/hooks/use-toast";
import Navigation from "@/components/navigation";
import MobileNav from "@/components/mobile-nav";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Car, Calendar, Clock } from "lucide-react";
import type { Booking } from "@shared/schema";

export default function Profile() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: userBookings, isLoading: bookingsLoading } = useQuery<Booking[]>({
    queryKey: ["/api/bookings/user"],
    retry: false,
  });

  const completedBookings = userBookings?.filter(booking => booking.status === 'completed') || [];
  const totalSpent = completedBookings.reduce((sum, booking) => sum + parseFloat(booking.fare), 0);
  
  const memberSince = user?.createdAt ? new Date(user.createdAt) : new Date();
  const monthsSince = Math.floor((new Date().getTime() - memberSince.getTime()) / (1000 * 60 * 60 * 24 * 30));

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-0">
      <Navigation />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Profile Header */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex items-center space-x-6">
              <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center">
                <span className="text-2xl font-bold text-white">
                  {user?.firstName?.charAt(0) || 'U'}{user?.lastName?.charAt(0) || ''}
                </span>
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-gray-900">
                  {user?.firstName} {user?.lastName}
                </h2>
                <p className="text-gray-600">{user?.email}</p>
                {user?.phone && <p className="text-gray-600">{user.phone}</p>}
              </div>
              <Button className="bg-primary hover:bg-primary/90">
                Edit Profile
              </Button>
            </div>
          </CardContent>
        </Card>
        
        {/* Profile Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-6">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-primary mb-2">
                {userBookings?.length || 0}
              </div>
              <p className="text-gray-600">Total Rides</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-primary mb-2">
                ₹{totalSpent.toFixed(2)}
              </div>
              <p className="text-gray-600">Total Spent</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-primary mb-2">
                {monthsSince > 0 ? `${monthsSince} months` : 'New member'}
              </div>
              <p className="text-gray-600">Member Since</p>
            </CardContent>
          </Card>
        </div>
        
        {/* Ride History */}
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-semibold text-gray-900">Ride History</h3>
              <div className="flex space-x-2">
                <Badge variant="secondary">All</Badge>
                <Badge variant="outline">Completed</Badge>
                <Badge variant="outline">Cancelled</Badge>
              </div>
            </div>
            
            {bookingsLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="border border-gray-200 rounded-lg p-4 animate-pulse">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex-1">
                        <div className="h-4 bg-gray-300 rounded w-2/3 mb-2"></div>
                        <div className="h-4 bg-gray-300 rounded w-2/3 mb-2"></div>
                        <div className="h-3 bg-gray-300 rounded w-1/3"></div>
                      </div>
                      <div className="text-right">
                        <div className="h-5 bg-gray-300 rounded w-16 mb-2"></div>
                        <div className="h-4 bg-gray-300 rounded w-20"></div>
                      </div>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <div className="h-3 bg-gray-300 rounded w-16"></div>
                      <div className="h-3 bg-gray-300 rounded w-16"></div>
                      <div className="h-3 bg-gray-300 rounded w-16"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : userBookings && userBookings.length > 0 ? (
              <div className="space-y-4">
                {userBookings.map((booking) => (
                  <div key={booking.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <MapPin className="h-4 w-4 text-green-500" />
                          <span className="text-sm text-gray-600">{booking.pickupLocation}</span>
                        </div>
                        <div className="flex items-center space-x-2 mb-2">
                          <MapPin className="h-4 w-4 text-red-500" />
                          <span className="text-sm text-gray-600">{booking.dropLocation}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Calendar className="h-4 w-4 text-gray-400" />
                          <span className="text-xs text-gray-500">
                            {booking.bookedAt && new Date(booking.bookedAt).toLocaleDateString()} - {booking.bookedAt && new Date(booking.bookedAt).toLocaleTimeString()}
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-primary text-lg">₹{booking.fare}</p>
                        <Badge 
                          variant={
                            booking.status === 'completed' ? 'default' :
                            booking.status === 'ongoing' ? 'secondary' :
                            booking.status === 'cancelled' ? 'destructive' :
                            'outline'
                          }
                        >
                          {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                        </Badge>
                      </div>
                    </div>
                    <div className="flex justify-between items-center text-sm text-gray-600">
                      <span>Booking #{booking.id}</span>
                      <span>{booking.estimatedDistance} km</span>
                      <div className="flex items-center space-x-1">
                        <Clock className="h-4 w-4" />
                        <span>
                          {booking.status === 'completed' && booking.completedAt
                            ? `Completed in ${Math.floor((new Date(booking.completedAt).getTime() - new Date(booking.bookedAt).getTime()) / (1000 * 60))} mins`
                            : booking.status === 'cancelled'
                            ? 'Cancelled'
                            : 'In progress'
                          }
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Car className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">No rides yet</p>
                <p className="text-sm text-gray-400">Your ride history will appear here once you book your first ride</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <MobileNav />
    </div>
  );
}
