import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  decimal,
  integer,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  phone: varchar("phone"),
  verified: boolean("verified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Cab types table
export const cabTypes = pgTable("cab_types", {
  id: serial("id").primaryKey(),
  type: varchar("type").notNull().unique(), // Mini, Sedan, SUV
  baseFare: decimal("base_fare", { precision: 8, scale: 2 }).notNull(),
  perKmRate: decimal("per_km_rate", { precision: 8, scale: 2 }).notNull(),
  capacity: integer("capacity").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Bookings table
export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  pickupLocation: text("pickup_location").notNull(),
  dropLocation: text("drop_location").notNull(),
  cabTypeId: integer("cab_type_id").notNull().references(() => cabTypes.id),
  estimatedDistance: decimal("estimated_distance", { precision: 8, scale: 2 }),
  fare: decimal("fare", { precision: 8, scale: 2 }).notNull(),
  status: varchar("status").notNull().default("pending"), // pending, confirmed, ongoing, completed, cancelled
  scheduledAt: timestamp("scheduled_at"),
  bookedAt: timestamp("booked_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Create insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  firstName: true,
  lastName: true,
  phone: true,
});

export const insertCabTypeSchema = createInsertSchema(cabTypes).omit({
  id: true,
  createdAt: true,
});

export const insertBookingSchema = createInsertSchema(bookings).omit({
  id: true,
  bookedAt: true,
  completedAt: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  pickupLocation: z.string().min(1, "Pickup location is required"),
  dropLocation: z.string().min(1, "Drop location is required"),
  fare: z.string().transform(val => parseFloat(val)),
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type CabType = typeof cabTypes.$inferSelect;
export type InsertCabType = z.infer<typeof insertCabTypeSchema>;
export type Booking = typeof bookings.$inferSelect;
export type InsertBooking = z.infer<typeof insertBookingSchema>;

// Relations would be defined here if needed
