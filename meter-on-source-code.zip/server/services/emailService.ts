interface BookingDetails {
  bookingId: number;
  pickupLocation: string;
  dropLocation: string;
  cabType: string;
  fare: number;
  scheduledAt?: Date | null;
}

class EmailService {
  async sendBookingConfirmation(email: string, bookingDetails: BookingDetails): Promise<void> {
    // In a real implementation, you would use a service like:
    // - Nodemailer with SMTP
    // - SendGrid
    // - AWS SES
    // - Mailgun
    
    console.log(`Email would be sent to: ${email}`);
    console.log('Booking confirmation details:', {
      bookingId: bookingDetails.bookingId,
      pickup: bookingDetails.pickupLocation,
      drop: bookingDetails.dropLocation,
      cabType: bookingDetails.cabType,
      fare: `₹${bookingDetails.fare}`,
      scheduledAt: bookingDetails.scheduledAt,
    });
    
    // Mock email sending
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log(`✅ Booking confirmation email sent to ${email}`);
        resolve();
      }, 100);
    });
  }

  async sendOTP(email: string, otp: string): Promise<void> {
    console.log(`OTP ${otp} would be sent to: ${email}`);
    
    // Mock OTP email
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log(`✅ OTP email sent to ${email}`);
        resolve();
      }, 100);
    });
  }

  async sendAdminNotification(subject: string, message: string): Promise<void> {
    console.log('Admin notification:', { subject, message });
    
    // Mock admin notification
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log(`✅ Admin notification sent: ${subject}`);
        resolve();
      }, 100);
    });
  }
}

export const emailService = new EmailService();
