import {
  users,
  bookings,
  cabTypes,
  type User,
  type UpsertUser,
  type Booking,
  type InsertBooking,
  type CabType,
  type InsertCabType,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, count, sum, sql } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Cab type operations
  getCabTypes(): Promise<CabType[]>;
  getCabType(id: number): Promise<CabType | undefined>;
  createCabType(cabType: InsertCabType): Promise<CabType>;
  
  // Booking operations
  createBooking(booking: InsertBooking): Promise<Booking>;
  getBookingById(id: number): Promise<Booking | undefined>;
  getBookingsByUser(userId: string): Promise<Booking[]>;
  getAllBookings(): Promise<(Booking & { user: User; cabType: CabType })[]>;
  updateBookingStatus(id: number, status: string): Promise<Booking>;
  
  // Analytics
  getDashboardStats(): Promise<{
    totalUsers: number;
    activeBookings: number;
    todayRevenue: number;
    totalRides: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Cab type operations
  async getCabTypes(): Promise<CabType[]> {
    return await db.select().from(cabTypes);
  }

  async getCabType(id: number): Promise<CabType | undefined> {
    const [cabType] = await db.select().from(cabTypes).where(eq(cabTypes.id, id));
    return cabType;
  }

  async createCabType(cabType: InsertCabType): Promise<CabType> {
    const [newCabType] = await db.insert(cabTypes).values(cabType).returning();
    return newCabType;
  }

  // Booking operations
  async createBooking(booking: InsertBooking): Promise<Booking> {
    const [newBooking] = await db.insert(bookings).values({
      ...booking,
      fare: booking.fare.toString(),
      estimatedDistance: booking.estimatedDistance?.toString() || null,
    }).returning();
    return newBooking;
  }

  async getBookingById(id: number): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings).where(eq(bookings.id, id));
    return booking;
  }

  async getBookingsByUser(userId: string): Promise<Booking[]> {
    return await db
      .select()
      .from(bookings)
      .where(eq(bookings.userId, userId))
      .orderBy(desc(bookings.createdAt));
  }

  async getAllBookings(): Promise<(Booking & { user: User; cabType: CabType })[]> {
    const result = await db
      .select({
        id: bookings.id,
        userId: bookings.userId,
        pickupLocation: bookings.pickupLocation,
        dropLocation: bookings.dropLocation,
        cabTypeId: bookings.cabTypeId,
        estimatedDistance: bookings.estimatedDistance,
        fare: bookings.fare,
        status: bookings.status,
        scheduledAt: bookings.scheduledAt,
        bookedAt: bookings.bookedAt,
        completedAt: bookings.completedAt,
        notes: bookings.notes,
        createdAt: bookings.createdAt,
        updatedAt: bookings.updatedAt,
        user: users,
        cabType: cabTypes,
      })
      .from(bookings)
      .leftJoin(users, eq(bookings.userId, users.id))
      .leftJoin(cabTypes, eq(bookings.cabTypeId, cabTypes.id))
      .orderBy(desc(bookings.createdAt));
    
    return result.filter(item => item.user && item.cabType) as (Booking & { user: User; cabType: CabType })[];
  }

  async updateBookingStatus(id: number, status: string): Promise<Booking> {
    const [updatedBooking] = await db
      .update(bookings)
      .set({ status, updatedAt: new Date() })
      .where(eq(bookings.id, id))
      .returning();
    return updatedBooking;
  }

  // Analytics
  async getDashboardStats(): Promise<{
    totalUsers: number;
    activeBookings: number;
    todayRevenue: number;
    totalRides: number;
  }> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const [totalUsersResult] = await db.select({ count: count() }).from(users);
    
    const [activeBookingsResult] = await db
      .select({ count: count() })
      .from(bookings)
      .where(eq(bookings.status, 'ongoing'));
    
    const [todayRevenueResult] = await db
      .select({ sum: sum(bookings.fare) })
      .from(bookings)
      .where(
        and(
          eq(bookings.status, 'completed'),
          sql`${bookings.completedAt} >= ${today}`,
          sql`${bookings.completedAt} < ${tomorrow}`
        )
      );
    
    const [totalRidesResult] = await db
      .select({ count: count() })
      .from(bookings)
      .where(eq(bookings.status, 'completed'));

    return {
      totalUsers: totalUsersResult.count,
      activeBookings: activeBookingsResult.count,
      todayRevenue: parseFloat(todayRevenueResult.sum || '0'),
      totalRides: totalRidesResult.count,
    };
  }
}

export const storage = new DatabaseStorage();
