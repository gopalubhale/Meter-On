import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertBookingSchema, insertCabTypeSchema } from "@shared/schema";
import { z } from "zod";
import { emailService } from "./services/emailService";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Cab types routes
  app.get('/api/cab-types', async (req, res) => {
    try {
      const cabTypes = await storage.getCabTypes();
      res.json(cabTypes);
    } catch (error) {
      console.error("Error fetching cab types:", error);
      res.status(500).json({ message: "Failed to fetch cab types" });
    }
  });

  app.post('/api/cab-types', isAuthenticated, async (req, res) => {
    try {
      const cabTypeData = insertCabTypeSchema.parse(req.body);
      const cabType = await storage.createCabType(cabTypeData);
      res.status(201).json(cabType);
    } catch (error) {
      console.error("Error creating cab type:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid cab type data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create cab type" });
      }
    }
  });

  // Booking routes
  app.post('/api/bookings', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const bookingData = insertBookingSchema.parse({ ...req.body, userId });
      
      const booking = await storage.createBooking(bookingData);
      
      // Send confirmation email
      const user = await storage.getUser(userId);
      const cabType = await storage.getCabType(booking.cabTypeId);
      
      if (user?.email && cabType) {
        await emailService.sendBookingConfirmation(user.email, {
          bookingId: booking.id,
          pickupLocation: booking.pickupLocation,
          dropLocation: booking.dropLocation,
          cabType: cabType.type,
          fare: parseFloat(booking.fare),
          scheduledAt: booking.scheduledAt,
        });
      }
      
      res.status(201).json(booking);
    } catch (error) {
      console.error("Error creating booking:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid booking data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create booking" });
      }
    }
  });

  app.get('/api/bookings/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const bookings = await storage.getBookingsByUser(userId);
      res.json(bookings);
    } catch (error) {
      console.error("Error fetching user bookings:", error);
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });

  app.get('/api/bookings', isAuthenticated, async (req, res) => {
    try {
      const bookings = await storage.getAllBookings();
      res.json(bookings);
    } catch (error) {
      console.error("Error fetching all bookings:", error);
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });

  app.patch('/api/bookings/:id/status', isAuthenticated, async (req, res) => {
    try {
      const bookingId = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!status) {
        return res.status(400).json({ message: "Status is required" });
      }
      
      const updatedBooking = await storage.updateBookingStatus(bookingId, status);
      res.json(updatedBooking);
    } catch (error) {
      console.error("Error updating booking status:", error);
      res.status(500).json({ message: "Failed to update booking status" });
    }
  });

  // Analytics routes
  app.get('/api/dashboard/stats', isAuthenticated, async (req, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Fare calculation endpoint
  app.post('/api/calculate-fare', async (req, res) => {
    try {
      const { distance, cabTypeId } = req.body;
      
      if (!distance || !cabTypeId) {
        return res.status(400).json({ message: "Distance and cab type are required" });
      }
      
      const cabType = await storage.getCabType(cabTypeId);
      if (!cabType) {
        return res.status(404).json({ message: "Cab type not found" });
      }
      
      const baseFare = parseFloat(cabType.baseFare);
      const perKmRate = parseFloat(cabType.perKmRate);
      const totalFare = baseFare + (distance * perKmRate);
      
      res.json({
        distance,
        baseFare,
        perKmRate,
        totalFare: parseFloat(totalFare.toFixed(2)),
      });
    } catch (error) {
      console.error("Error calculating fare:", error);
      res.status(500).json({ message: "Failed to calculate fare" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
