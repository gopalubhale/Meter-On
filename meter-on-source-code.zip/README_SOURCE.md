# Meter-On Cab Booking Application

A comprehensive full-stack cab booking platform built with React, Express.js, and PostgreSQL.

## Features

- User authentication via Replit Auth
- Interactive cab booking system with real-time map visualization
- Admin dashboard with analytics and booking management
- User profile and ride history
- Email notifications for bookings
- Mobile-responsive design with modern UI

## Tech Stack

### Frontend
- React 18 with TypeScript
- Tailwind CSS + shadcn/ui component library
- Wouter for lightweight routing
- TanStack Query for server state management
- React Hook Form + Zod validation

### Backend
- Node.js with Express.js
- PostgreSQL with Drizzle ORM
- Replit Auth (OpenID Connect)
- Session management with connect-pg-simple

## Installation

1. Clone or extract this project
2. Install dependencies:
   ```bash
   npm install
   ```

3. Set up environment variables:
   - `DATABASE_URL` - PostgreSQL connection string
   - `SESSION_SECRET` - Secret for session management
   - `REPL_ID` - Replit application ID
   - `REPLIT_DOMAINS` - Comma-separated domains for auth

4. Initialize database:
   ```bash
   npm run db:push
   ```

5. Start development server:
   ```bash
   npm run dev
   ```

## Project Structure

```
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/         # Route pages (home, booking, admin, profile)
│   │   ├── hooks/         # Custom React hooks
│   │   └── lib/           # Utilities and helpers
├── server/                # Express backend
│   ├── services/          # Business logic services
│   ├── db.ts             # Database connection setup
│   ├── routes.ts         # API route definitions
│   ├── storage.ts        # Data access layer
│   └── replitAuth.ts     # Authentication middleware
├── shared/               # Shared types and schemas
│   └── schema.ts         # Drizzle database schema
└── components.json       # shadcn/ui configuration
```

## Database Schema

- **users**: User authentication and profile data
- **bookings**: Ride booking records with status tracking
- **cab_types**: Vehicle types and pricing configuration
- **sessions**: Session storage for authentication

## API Endpoints

### Authentication
- `GET /api/auth/user` - Get current authenticated user
- `GET /api/login` - Initiate login flow
- `GET /api/logout` - Logout and clear session

### Bookings
- `GET /api/cab-types` - Get available cab types and pricing
- `POST /api/bookings` - Create new booking
- `GET /api/bookings/user` - Get user's booking history
- `GET /api/bookings` - Get all bookings (admin)
- `POST /api/calculate-fare` - Calculate fare estimate

### Admin Dashboard
- `GET /api/dashboard/stats` - Get system statistics

## Key Features

1. **Interactive Map**: Visual route display with pickup/drop markers and animated path
2. **Fare Calculator**: Real-time fare estimation based on distance and cab type
3. **Admin Dashboard**: Comprehensive user and booking management
4. **Mobile Responsive**: Optimized for all device sizes
5. **Email Notifications**: Booking confirmations and admin alerts
6. **Real-time Updates**: Live booking status and system metrics

## Deployment

This application is designed for Replit deployment but can be adapted for other platforms by:
1. Replacing Replit Auth with alternative authentication (Auth0, Firebase, etc.)
2. Adjusting environment variable configuration
3. Setting up appropriate hosting for Node.js + PostgreSQL

## Development Notes

- Uses TypeScript throughout for type safety
- Implements proper error handling and loading states
- Follows modern React patterns with hooks
- Uses Drizzle ORM for type-safe database operations
- Includes comprehensive form validation
- Implements proper session management

## License

MIT License - Feel free to modify and use for your projects.

---

Built with modern web technologies for scalable cab booking platform